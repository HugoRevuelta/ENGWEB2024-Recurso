const mongoose = require('mongoose')
var Livro = require("../models/livros")

module.exports.list = () => {
    return Livro
        .find()
        .sort({bookId : 1})
        .exec()
}

module.exports.findByCharacter = character => {
    return Livro
        .find({characters:{$elemMatch:{$regex: character, $options: 'i' } } })
        .exec()
};

module.exports.findByGenre = genre => {
    return Livro
        .find({genres:{$elemMatch:{$regex: genre, $options: 'i' } } })
        .exec()
};

module.exports.findById = id => {
    return Livro
        .findOne({bookId : id})
        .exec()
}

module.exports.obtenerCharacters = () => {
    return Livro
        .find().select("characters").distinct("characters").sort()
        .exec()
};


module.exports.insert = livro => {
    if((Livro.find({bookId : livro.bookId}).exec()).length != 1){
        var newLivro = new Livro(livro)
        return newLivro.save()
    }
}

module.exports.update = (id, livro) => {
    return Livro
        .updateOne({bookId : id}, livro)
}

module.exports.remove = idcontrato => {
    return Livro
        .findOneAndDelete({bookId : idcontrato})
}