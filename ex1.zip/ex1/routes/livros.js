var express = require('express');
var router = express.Router();
var Livro = require('../controllers/livros')

router.get('/', function(req, res){
    if(req.query.character){
        Livro.findByCharacter(req.query.character)
        .then(data => res.jsonp(data))
        .catch(erro => res.status(501).jsonp(erro))
    }
    else if(req.query.genre){
        Livro.findByGenre(req.query.genre)
        .then(data => res.jsonp(data))
        .catch(erro => res.status(502).jsonp(erro))
    }else{
        Livro.list()
        .then(data => res.jsonp(data))
        .catch(erro => res.status(503).jsonp(erro))
    }
    
router.get('/characters', function(req, res){
        Livro.obtenerCharacters()
        .then(data => res.jsonp(data))
        .catch(erro => res.status(504).jsonp(erro))
    })

router.get('/:id', function(req, res){
        Livro.findById(req.params.id)
        .then(data => res.jsonp(data))
        .catch(erro => res.status(506).jsonp(erro))
    })
router.post('/', function(req, res) {
        Livro.insert(req.body)
          .then(data => res.jsonp(data))
          .catch(erro => res.status(507).jsonp(erro))
      });

router.put('/:id', function(req, res) {
        Livro.update(req.params.id, req.body)
        .then(data => res.jsonp(data))
        .catch(erro => res.jsonp(erro))
    });
    
router.delete('/:id', function(req, res) {
        return Livro.remove(req.params.id)
        .then(data => res.jsonp(data))
        .catch(erro => res.jsonp(erro))
      }); 
});

module.exports = router;